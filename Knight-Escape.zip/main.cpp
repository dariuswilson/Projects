/*--------------------------------------------
   Program 2: Knight Escape
   The objective of this game is to get the white knight to the empty
	square in the upper right-hand corner of the board.
	
	The knight can only move in the way that it does during a traditional
	chess game. This means that a knight can only move in a valid L-shape
	(two squares in a horizontal direction, then one in a vertical direction OR 
	two squares in a vertical direction, then one in a horizontal direction).
		       
   Course: CS 141, Spring 2022
   System: 
   Author: Darius Wilson
    
 ---------------------------------------------*/

#include <iostream>		// for input and output
#include <cctype>		   // for toupper()
using namespace std;

// Global variables for the pieces are allowed for this program,
// but will generally not be allowed in the future.
// You will likely want to declare global variables at least for the 25 board positions.
// ...
string p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24,p25;
char menuOption = ' ';
int moveFrom;
int moveTo;
int moveNumber;
int score;
// Characters of the pieces to be used on the board
// Note that these are global constants, so their values cannot be changed.
const string WhiteKnight = "\u2658";		// White knight character
const string BlackKnight = "\u265E";		// Black knight character
const string BlankPosition = " ";			// Blank position character

//--------------------------------------------------------------------------------
// Display welcome message, introducing the user to the program and
// describing the instructions for the game
void displayWelcomeMessage()
{
    cout << "Program 2: Knight Escape \n"
         << "CS 141, Spring 2022, UIC \n"
         << " \n"
         << "The objective of this puzzle is to get the white knight "
		 << "up to the empty square in the top right corner of the board. "
		 << "Use standard knight moves from a traditional chess game, "
		 << "where a knight moves in an L-shape. \n"
		 << "This means that a knight can only move either "
		 << "1) two squares in a horizontal direction, then one in a vertical direction, OR "
		 << "2) two squares in a vertical direction, then one in a horizontal direction."
		 << " \n"
		 << "Your score decreases by 5 with each valid move, and by 10 with each invalid move. \n"
		 << "Try to complete the puzzle with the smallest number of valid moves!"
    	 << endl;
}//end displayWelcomeMessage()

// Swap function
void UpdateValue(int position, string newValue) {
  if(position == 1) {
    p1 = newValue;
  }
  if(position == 2) {
    p2 = newValue;
  }
  if(position == 3) {
    p3 = newValue;
  }
  if(position == 4) {
    p4 = newValue;
  }
  if(position == 5) {
    p5 = newValue;
  }
  if(position == 6) {
    p6 = newValue;
  }
  if(position == 7) {
    p7 = newValue;
  }
  if(position == 8) {
    p8 = newValue;
  }
  if(position == 9) {
    p9 = newValue;
  }
  if(position == 10) {
    p10 = newValue;
  }
  if(position == 11) {
    p11 = newValue;
  }
  if(position == 12) {
    p12 = newValue;
  }
  if(position == 13) {
    p13 = newValue;
  }
  if(position == 14) {
    p14 = newValue;
  }
  if(position == 15) {
    p15 = newValue;
  }
  if(position == 16) {
    p16 = newValue;
  }
  if(position == 17) {
    p17 = newValue;
  }
  if(position == 18) {
    p18 = newValue;
  }
  if(position == 19) {
    p19 = newValue;
  }
  if(position == 20) {
    p20 = newValue;
  }
  if(position == 21) {
    p21 = newValue;
  }
  if(position == 22) {
    p22 = newValue;
  }
  if(position == 23) {
    p23 = newValue;
  }
  if(position == 24) {
    p24 = newValue;
  }
  if(position == 25) {
    p25 = newValue;
  }
}
    
// ----------------------------------------------------------------------
// Display the current board, along with the corresponding positions
// This function makes use of global variables p1..p25, which represent
// each of the positions on the board
void displayBoard()
{
    cout <<"\n"
         <<                          "    Board   " <<                               "      Position \n"
         << " " <<  p1 << " " <<  p2 << " " <<  p3 << " " <<  p4 << " " <<  p5 << "     1  2  3  4  5 \n"
         << " " <<  p6 << " " <<  p7 << " " <<  p8 << " " <<  p9 << " " << p10 << "     6  7  8  9 10 \n"
         << " " << p11 << " " << p12 << " " << p13 << " " << p14 << " " << p15 << "    11 12 13 14 15 \n"
         << " " << p16 << " " << p17 << " " << p18 << " " << p19 << " " << p20 << "    16 17 18 19 20 \n"
         << " " << p21 << " " << p22 << " " << p23 << " " << p24 << " " << p25 << "    21 22 23 24 25 \n"
         << endl;
} //end displayBoard()

// Setting the board.
void setBoard() {
  p1=p2=p3=p4=p6=p7=p8=p9=p10=p11=p12=p13=p14=p15=p16=p17=p18=p19=p20=p22=p23=p24=p25 =BlackKnight;
  p21=WhiteKnight;
  p5=BlankPosition;
  moveNumber = 1;
  score = 500;
}

// Switching string to int
string returnStrPosition(int position) {
  switch(position){
    case 1:
      return p1;
    case 2:
      return p2;
    case 3:
      return p3;
    case 4:
      return p4;
    case 5:
      return p5;
    case 6:
      return p6;
    case 7:
      return p7;
    case 8:
      return p8;
    case 9:
      return p9;
    case 10:
      return p10;
    case 11:
      return p11;
    case 12:
      return p12;
    case 13:
      return p13;
    case 14:
      return p14;
    case 15:
      return p15;
    case 16:
      return p16;
    case 17:
      return p17;
    case 18:
      return p18;
    case 19:
      return p19;
    case 20:
      return p20;
    case 21:
      return p21;
    case 22:
      return p22;
    case 23:
      return p23;
    case 24:
      return p24;
    case 25:
      return p25;
  }
  return " ";
}

// ----------------------------------------------------------------------

// boolean to check if moveFrom and moveTo is in L Shape and is valid for switch.
bool checkLShape(int moveFrom, int moveTo) {
  if (moveFrom == 1) {
    if (moveTo == 8 || moveTo == 12) {
      return true;
    }
} 
  else if (moveFrom == 2) {
    if (moveTo == 9 || moveTo == 11 || moveTo == 13) {
      return true;
    }
}
  else if (moveFrom == 3) {
    if (moveTo == 10 || moveTo == 6 || moveTo == 12 || moveTo == 14) {
      return true;
    }
}
  else if (moveFrom == 4) {
    if (moveTo == 7 || moveTo == 13 || moveTo == 15) {
      return true;
    }
}
  else if (moveFrom == 5) {
    if (moveTo == 14 || moveTo == 8) {
      return true;
    }
}
  else if (moveFrom == 6) {
    if (moveTo == 13 || moveTo == 17) {
      return true;
    }
}
  else if (moveFrom == 7) {
    if (moveTo == 14 || moveTo == 16 || moveTo == 18) {
      return true;
    }
}
  else if (moveFrom == 8) {
    if (moveTo == 15 || moveTo == 11 || moveTo == 17 || moveTo == 19 || moveTo == 5) {
      return true;
    }
}
  else if (moveFrom == 9) {
    if (moveTo == 12 || moveTo == 18 || moveTo == 20) {
      return true;
    }
}
  else if (moveFrom == 10) {
    if (moveTo == 13 || moveTo == 19 || moveTo == 3 || moveTo == 8) {
      return true;
    }
}
  else if (moveFrom == 11) {
    if (moveTo == 2 || moveTo == 18 || moveTo == 22 ) {
      return true;
    }
}
  else if (moveFrom == 12) {
    if (moveTo == 19 || moveTo == 3 || moveTo == 21 || moveTo == 23 || moveTo == 1) {
      return true;
    }
}
  else if (moveFrom == 13) {
    if (moveTo == 24 || moveTo == 4 || moveTo == 2 || moveTo == 20 || moveTo == 16 || moveTo == 6 || moveTo == 22 || moveTo == 10) {
      return true;
    }
}
  else if (moveFrom == 14) {
    if (moveTo == 5 || moveTo == 3 || moveTo == 17 || moveTo == 23 || moveTo == 25 || moveTo == 7) {
      return true;
    }
}
  else if (moveFrom == 15) {
    if (moveTo == 4 || moveTo == 8 || moveTo == 18 || moveTo == 24) {
      return true;
    }
}
  else if (moveFrom == 16) {
    if (moveTo == 7 || moveTo == 23) {
      return true;
    }
}
  else if (moveFrom == 17) {
    if (moveTo == 8 || moveTo == 6 || moveTo == 24 || moveTo == 14) {
      return true;
    }
}
  else if (moveFrom == 18) {
    if (moveTo == 7 || moveTo == 9 || moveTo == 25 || moveTo == 21) {
      return true;
    }
}
  else if (moveFrom == 19) {
    if (moveTo == 10 || moveTo == 8 || moveTo == 12 || moveTo == 22) {
      return true;
    }
}
  else if (moveFrom == 20) {
    if (moveTo == 9 || moveTo == 13 || moveTo == 23) {
      return true;
    }
}
  else if (moveFrom == 21) {
    if (moveTo == 12 || moveTo == 18) {
      return true;
    }
}
  else if (moveFrom == 22) {
    if (moveTo == 11 || moveTo == 13 || moveTo == 19) {
      return true;
    }
}
  else if (moveFrom == 23) {
    if (moveTo == 12 || moveTo == 14 || moveTo == 20 || moveTo == 16) {
      return true;
    }
}
  else if (moveFrom == 24) {
    if (moveTo == 17 || moveTo == 13 || moveTo == 15) {
      return true;
    }
}
  else if (moveFrom == 25) {
    if (moveTo == 14 || moveTo == 18) {
      return true;
    }
  }
  return false;
}
// Main() function of the program, containing the loop that controls
// game play
int main() {
  int moveNumber = 1;
  int score = 500;
   
  displayWelcomeMessage();
	setBoard();
	// Set board values to the default starting position
  displayBoard();
   
   // Loop that controls game play
   while((p5 != WhiteKnight) && (score > 0)) {
      cout << "\nCurrent score: " << score << endl;
      cout << moveNumber << ". "
             << "Enter one of the following: \n"
			 << "  - M to move a knight from one position to another, \n"
			 << "  - R to reset the board back to the beginning, or \n"
			 << "  - X to exit the game. \n"
			 << "Your choice -> ";
		cin >> menuOption;
		menuOption = toupper(menuOption); // convert user input to uppercase
		
		// If the user entered 'X' to exit,
		// break out of this loop that controls game play
    if (menuOption == 'X') {
      cout << "Exiting..." << endl;
      break;
    }
		
		// If the user entered 'R' to reset,
		// reset the board back to the beginning
		if (menuOption == 'R') {
      cout << "\n *** Restarting" << endl;
      setBoard();
      displayBoard();
      score = 500;
      moveNumber = 1;
      continue;
    }
		
		// If the user entered 'M' to move a knight,
		// ask for the position of the knight to be moved
		if (menuOption == 'M') {
      cout << "Enter the positions from and to, separated by a space (e.g. 14 5 to move the knight in position 14 to position 5): " << endl;
      cin >> moveFrom >> moveTo;
      cout << "You have chosen to move a knight from position " << moveFrom << " to position " << moveTo << "." << endl;
    }
		
		// Check that FROM position is valid, i.e. within 1-25
		if (moveFrom < 1 || moveFrom > 25) {
      cout << "The source position should be a valid position on the board (1-25). Try again." << endl;
      score -= 10;
      if (score <= 0) {
        cout << "Current score: " << score << endl;
        cout << endl << "You have run out of moves. Try to do better next time!" << endl;
        break;
    }
    continue;
  }
		// Check that TO position is valid, i.e. within 1-25
    if(moveTo < 1 || moveTo > 25) {
      cout << "The destination position should be a valid position on the board (1-25). Try again." << endl;
      score -= 10;
      if (score <= 0) {
        cout << "Current score: " << score << endl;
        cout << endl << "You have run out of moves. Try to do better next time!" << endl;
        break;
      }
      continue;
    }
		// Check that the source position has a knight
    if (returnStrPosition(moveFrom) == BlankPosition) {
      cout << "The source position should have a knight. Try again." << endl;
      score -= 10;
      if (score <= 0) {
        cout << "Current score: " << score << endl;
        cout << endl << "You have run out of moves. Try to do better next time!" << endl;
        break;
      }
      continue;
    }
		// Check that the destination position is empty
    if(returnStrPosition(moveTo) == WhiteKnight || returnStrPosition(moveTo) == BlackKnight) {
      cout << "The destination position should be empty. Try again." << endl;
      score -= 10;
      if (score <= 0) {
        cout << "Current score: " << score << endl;
        cout << endl << "You have run out of moves. Try to do better next time!" << endl;
        break;
    }
    continue;
  }
		// Check that the move is valid - knights can only move in an L-shape
  if (checkLShape(moveFrom, moveTo) == false ){
    cout << "Invalid move. Knights can only move in an L-shape. Try again." << endl;
    score -= 10;
    if (score <= 0) {
      cout << "Current score: " << score << endl;
      cout << endl << "You have run out of moves. Try to do better next time!" << endl;
      break;
    }
    continue;
  }
		// // Make the move and update the board
  string tempFrom = returnStrPosition(moveFrom);
  string tempTo = returnStrPosition(moveTo);
  UpdateValue(moveFrom, tempTo);
  UpdateValue(moveTo, tempFrom);
  moveNumber++;
  displayBoard();
   // Check for a win
  if (p5 == WhiteKnight) {
    displayBoard();
    cout << endl << "Congratulations, you did it!" << endl;
    break;
  }
  score -= 5;
  // Checking for loss
  if (score <= 0) {
    cout << "Current score: " << score << endl;
    cout << endl << "You have run out of moves. Try to do better next time!" << endl;
    break;
  }
} // end loop for game play
  cout << "Thank you for playing!" << endl;

	return 0;
}