######################################################
# Project: Project 1
# Student Name:  <Wilson, Darius>
# UIN: <674790859>
# URL: <https://replit.com/@DariusWilson3/Snowman-Project-1>
######################################################
import turtle
import random

# Turtle
t = turtle.Turtle()
t2 = turtle.Turtle()
t3 = turtle.Turtle()
t4 = turtle.Turtle()
t1 = turtle.Turtle()

#List for turtles
turtles = [t, t2, t3, t4, t1]


#Function to draw snow
def draw_snow(turtle, heading, pensize, pen_color, fill_color, radius, extent, steps):
  turtle.penup()
  turtle.setheading(heading)
  turtle.pensize(pensize)
  turtle.pencolor(pen_color)
  turtle.fillcolor(fill_color)
  turtle.down()
  turtle.begin_fill()
  turtle.circle(radius)
  turtle.end_fill()

#Function for background
def draw_background():
  s = turtle.Screen()
  s.setup(525,525)
  s.screensize(500,500)
  s.bgcolor("#69D9FF")
  s.tracer(0)
  s.update()
  for i in range(50):
    rand_x = random.randint(-300,300)
    rand_y = random.randint(-300,300)
    draw_snow(t2, 0, 5, "white", "white", 1, 2, 3) 
    t2.penup()
    t2.goto (rand_x, rand_y)
    t2.pendown()
    if(rand_y <= 20):
      t.stamp()


#Body of snowman
def draw_circle(turtle, x, y, heading, pensize, pen_color, fill_color, radius, extent, steps):
  turtle.penup()
  turtle.goto(x, y)
  turtle.setheading(heading)
  turtle.pensize(pensize)
  turtle.pencolor(pen_color)
  turtle.fillcolor(fill_color)
  turtle.down()
  turtle.begin_fill()
  turtle.circle(radius)
  turtle.end_fill()

#Buttons
def draw_triangle(turtle, x, y, heading, pensize, pen_color, fill_color, side_length):
  turtle.penup()
  turtle.goto(x, y)
  turtle.setheading(heading)
  turtle.pensize(pensize)
  turtle.pencolor(pen_color)
  turtle.fillcolor(fill_color)
  turtle.down()
  turtle.begin_fill()
  for i in range(3):
    turtle.forward(side_length)
    turtle.left(120)
  turtle.end_fill()


def draw_rectangle(turtle, x, y, heading, pensize, pen_color, fill_color, length, width):
  turtle.penup()
  turtle.goto(x, y)
  turtle.pensize(pensize)
  turtle.pencolor(pen_color)
  turtle.fillcolor(fill_color)
  turtle.down()
  turtle.begin_fill()
  for i in range(2):
    turtle.forward(width)
    turtle.left(90)
    turtle.forward(length)
    turtle.left(90)
  turtle.end_fill()
  turtle.setheading(heading)

def draw_snowman():
  draw_circle(t, 0, -180, 5, 5, "white", "white", 90, 0, 0) #Bottom
  draw_circle(t, 0, -60, 5, 5, "white", "white", 70, 0, 0) #middle
  draw_circle(t, 0, 50, 5, 5, "white", "white", 50, 0, 0)#Top
#Eyes
  draw_circle(t, -15, 110, 5, 5, "black", "black", 9, 0, 0)
  draw_circle(t, 15, 110, 5, 5, "black", "black", 9, 0, 0)
#Mouth
  draw_circle(t, 0, 80, 5, 5, "red", "red", 12, 0, 0)
  draw_circle(t, 0, 85, 5, 5, "white", "white", 12, 0, 0)
#Left ARm
  t.left(-45)
  draw_rectangle(t, 50, 25, 0, 1, "brown", "brown", 50, 5)
  t.left(0)
  draw_rectangle(t, 75, 50, 0, 1, "brown", "brown", 20, 3)
  t.left(-90)
  draw_rectangle(t, 75, 50, 0, 1, "brown", "brown", 20, 3)
# Right Arm
  t.right(-45)
  draw_rectangle(t, -65, 25, 0, 1, "brown", "brown", 50, 5)
  t.left(0)
  draw_rectangle(t, -85, 45, 0, 1, "brown", "brown", 20, 3)
  t.left(90)
  draw_rectangle(t, -80, 45, 0, 1, "brown", "brown", 20, 3)

def draw_header():
  t1.penup()
  t1.goto(0, 200)
  t1.color('black')
  t1.pendown()
  t1.write("Merry Christmas!",move=False, align='center', font=('Arial', 25, 'normal'))

def main():
  draw_background()
  draw_snowman()
  draw_header()
  y = -150
  for i in range(5):
    draw_triangle(t, -10, y, 0, 5, "black", "black", 10)
    y = y + 45

main()

print("Darius Wilson - 674790859")

## information for scorers

## on what line number is the required for loop?
## <40, 71, 85, 130>

## on what line number is the required use of a random number?
## <41, 42>

## on what line number is the required use of a conditional statement?
## <48>

## on what line number is the required use of a list?
## <18>

